<?php
// See all errors and warnings
error_reporting(E_ALL);
ini_set('error_reporting', E_ALL);

// Your database details might be different
$mysqli = mysqli_connect("localhost", "root", "mysql", "dbUser");

$email = isset($_POST["loginName"]) ? $_POST["loginName"] : false;
$pass = isset($_POST["loginPassw"]) ? $_POST["loginPassw"] : false;
?>

<!DOCTYPE html>
<html>
<head>
    <title>IMY 220 - Assignment 3</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <meta charset="utf-8" />
    <meta name="author" content="Armin van Wyk">
    <!-- Replace Name Surname with your name and surname -->
</head>
<body>
<div class="container">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <?php
    if($email && $pass){
        if(isset($_POST["submit"])) {
            $nameoffile = $_FILES["picToUpload"]["name"];
            $ext = pathinfo($nameoffile[0], PATHINFO_EXTENSION);
            $query2 = "SELECT user_id FROM tbusers WHERE email = '$email' AND password = '$pass'";
            $res = $mysqli->query($query2);
            $obj = $res->fetch_object();
                $query = "INSERT INTO tbgallery (user_id, filename) VALUES ('$obj->user_id','$nameoffile[0]')";
                $mysqli->query($query);
            if (($ext == "jpeg" || $ext == "jpg") && $_FILES["picToUpload"]["size"][0] < 1000000) {
                echo '<script type="text/javascript">
            console.log(' . $_FILES["picToUpload"]["size"][0] . ');
            </script>';

                $target_dir = dirname("IMY220ASS3\login.php");
                $target2 = $target_dir."\gallery";
                $target_file = $target2 . basename($_FILES["picToUpload"]["name"][0]);
                move_uploaded_file($_FILES["picToUpload"]["tmp_name"][0],
                    __DIR__.'gallery/');
            }
        }
        $query = "SELECT * FROM tbusers WHERE email = '$email' AND password = '$pass'";
        $res = $mysqli->query($query);
        if($row = mysqli_fetch_array($res)) {
            echo "<table class='table table-bordered mt-3'>
								<tr>
									<td>Name</td>
									<td>" . $row['name'] . "</td>
								<tr>
								<tr>
									<td>Surname</td>
									<td>" . $row['surname'] . "</td>
								<tr>
								<tr>
									<td>Email Address</td>
									<td>" . $row['email'] . "</td>
								<tr>
								<tr>
									<td>Birthday</td>
									<td>" . $row['birthday'] . "</td>
								<tr>
							</table>";

            echo "<form enctype='multipart/form-data' action='' method='post'>
								<div class='form-group'>
									<input type='file' class='form-control' name='picToUpload[]' id='picToUpload' /><br/>
									<input type='hidden' name='loginName' value='$email'>
									<input type='hidden' name='loginPassw' value='$pass'>
									<input type='submit' class='btn btn-standard' value='Upload Image' name='submit' />
								</div>
						  	</form>";
            $query2 = "SELECT user_id FROM tbusers WHERE email = '$email' AND password = '$pass'";
            $res = $mysqli->query($query2);
            $obj = $res->fetch_object();
            $sql = "SELECT filename FROM tbgallery WHERE user_id = '$obj->user_id'";
            $results = mysqli_query($mysqli, $sql);
            if (mysqli_num_rows($results) > 0) {
                    echo '<div class="row imageGallery">
<div class="col-3" style="background-image: url(gallery/Unchart.jpg)"></div>
<div class="col-3" style="background-image: url(gallery/Unchart2.jpg)"></div>
<div class="col-3" style="background-image: url(gallery/Unchart3.jpg)"></div>
</div>';

                }

            }

        else {
            echo 	'<div class="alert alert-danger mt-3" role="alert">
	  							You are not registered on this site!
	  						</div>';
        }
        }
    else{
        echo 	'<div class="alert alert-danger mt-3" role="alert">
	  						Could not log you in
	  					</div>';
    }
    
    ?>
</div>
</body>
</html>